package com.example.bookknowledge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookKnowledgeApplicationTests {

    @Test
    void contextLoads() {
    }

}
