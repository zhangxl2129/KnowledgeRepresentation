package com.example.bookknowledge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookKnowledgeApplication {

    public static void main(String[] args) {

        SpringApplication.run(BookKnowledgeApplication.class, args);

    }

}
