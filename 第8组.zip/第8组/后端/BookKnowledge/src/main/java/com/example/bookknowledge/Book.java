package com.example.bookknowledge;

public class Book {
    private String title;
    private String author;
    private String publishedYear;
    private String category;

    // 构造函数
    public Book() {}

    public Book(String title, String author, String publishedYear, String category) {
        this.title = title;
        this.author = author;
        this.publishedYear = publishedYear;
        this.category = category;
    }

    // Getter 和 Setter 方法
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublishedYear() {
        return publishedYear;
    }

    public void setPublishedYear(String publishedYear) {
        this.publishedYear = publishedYear;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
