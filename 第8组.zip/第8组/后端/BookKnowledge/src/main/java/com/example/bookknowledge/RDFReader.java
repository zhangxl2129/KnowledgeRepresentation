package com.example.bookknowledge;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.riot.Lang;

import java.io.FileInputStream;
import java.io.InputStream;

public class RDFReader {
    public static void main(String[] args) {
        Model model = ModelFactory.createDefaultModel();

        try (InputStream in = new FileInputStream("src/main/resources/books/books.rdf")) {
            model.read(in, null, "TURTLE");
            System.out.println("RDF 文件已成功加载，模型大小为: " + model.size());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
