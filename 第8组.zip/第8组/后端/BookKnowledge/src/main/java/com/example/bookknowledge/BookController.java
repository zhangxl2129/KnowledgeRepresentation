package com.example.bookknowledge;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @PostMapping
    public String addBook(@RequestBody Book book) {
        bookService.addBook(book);
        return "Book added: " + book.getTitle();
    }

    @GetMapping("/{title}")
    public Book getBookByTitle(@PathVariable String title) {
        Book book = bookService.getBookByTitle(title);
        if (book != null) {
            return book;
        } else {
            throw new RuntimeException("Book not found: " + title);
        }
    }

    @GetMapping
    public List<Book> queryAllBooks() {
        return bookService.queryAllBooks();
    }

    @GetMapping("/print")
    public String getBooks() {
        // 打印图书信息到控制台
        bookService.printBookInfo();
        return "Books information printed to console";
    }
    // 其他API方法...
}
