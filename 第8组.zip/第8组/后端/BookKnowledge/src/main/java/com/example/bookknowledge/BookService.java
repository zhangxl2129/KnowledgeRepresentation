package com.example.bookknowledge;

import com.example.bookknowledge.Book;
import org.apache.jena.query.*;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.util.FileManager;
import org.apache.jena.riot.Lang;
import org.apache.jena.riot.RDFDataMgr;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class BookService {

    private static final String RDF_FILE_PATH = "books/books.rdf";
    private static final String SCHEMA_FILE_PATH = "books/books_schema.rdfs";

    private Model model;

    public BookService() {
        // 加载 RDF 和 Schema 文件
        this.model = loadRDFModel(RDF_FILE_PATH, SCHEMA_FILE_PATH);
    }

    // 加载 RDF 文件并创建模型
    private Model loadRDFModel(String rdfFilePath, String schemaFilePath) {
        Model schema = ModelFactory.createDefaultModel();
        Model data = ModelFactory.createDefaultModel();

        // 加载 Schema 文件
        InputStream schemaStream = getClass().getClassLoader().getResourceAsStream(schemaFilePath);
        if (schemaStream == null) {
            throw new RuntimeException("无法找到 Schema 文件: " + schemaFilePath);
        }
        schema.read(schemaStream, null, Lang.TURTLE.getName());

        // 加载 RDF 数据文件
        InputStream dataStream = getClass().getClassLoader().getResourceAsStream(rdfFilePath);
        if (dataStream == null) {
            throw new RuntimeException("无法找到 RDF 数据文件: " + rdfFilePath);
        }
        data.read(dataStream, null, Lang.TURTLE.getName());
        // 合并模型
        schema.add(data);
        return schema;
    }

    // 添加图书信息
    public void addBook(Book book) {
        // 创建新的书籍资源
        Resource bookResource = model.createResource("http://example.org/" + book.getTitle().replace(" ", "_"))
                .addProperty(model.createProperty("http://example.org/hasTitle"), book.getTitle())
                .addProperty(model.createProperty("http://example.org/hasAuthor"), book.getAuthor())
                .addProperty(model.createProperty("http://example.org/publishedYear"), book.getPublishedYear())
                .addProperty(model.createProperty("http://example.org/belongsTo"), book.getCategory());

        System.out.println("Book added: " + book.getTitle());
    }

    // 通过书名查询图书信息
    public Book getBookByTitle(String title) {
            String queryStr = "PREFIX ex: <http://example.org/> SELECT ?book ?title ?author ?year " +
                "?category WHERE {?book a ex:Book ;ex:hasTitle " +
                "?title ;ex:hasAuthor ?author ;ex:publishedYear " +
                "?year ;ex:belongsTo ?category .FILTER (str(?title) = \\\"\" + title + \"\\\")}";
        Query query = QueryFactory.create(queryStr);
        try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
            ResultSet results = qexec.execSelect();
            if (results.hasNext()) {
                QuerySolution solution = results.nextSolution();
                String bookTitle = solution.getLiteral("title").getString();
                String author = solution.getLiteral("author").getString();
                String year = solution.getLiteral("year").getString();
                String category = solution.getLiteral("category").getString();
                // 创建并返回 Book 对象
                return new Book(bookTitle, author, year, category);
            }
        }
        return null; // 未找到图书时返回 null
    }

    // 查询所有图书
    public List<Book> queryAllBooks() {
        String queryStr =
                "PREFIX ex: <http://example.org/> " +
                        "SELECT ?book ?title ?author ?publisher ?date WHERE { " +
                        "  ?book a ex:Book ; " +
                        "        ex:hasTitle ?title ; " +
                        "        ex:hasAuthor ?author ; " +
                        "        ex:hasPublisher ?publisher ; " +
                        "        ex:publishDate ?date . " +
                        "}";

        Query query = QueryFactory.create(queryStr);
        List<Book> books = new ArrayList<>();
        try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
            ResultSet results = qexec.execSelect();
            while (results.hasNext()) {
                QuerySolution solution = results.nextSolution();
                System.out.println(solution);  // 打印出完整的结果
                String title = solution.getLiteral("title").getString();
                String author = solution.getLiteral("author").getString();
                String publisher = solution.getLiteral("publisher").getString();
                String date = solution.getLiteral("date").getString();

                books.add(new Book(title, author, publisher, date));
            }
        }

        System.out.println("查询到的书籍数量: " + books.size());
        return books;
    }



    // 打印图书信息
    public void printBookInfo() {
        List<Book> books = queryAllBooks();
        for (Book book : books) {
            System.out.println("Title: " + book.getTitle());
            System.out.println("Author: " + book.getAuthor());
            System.out.println("Year: " + book.getPublishedYear());
            System.out.println("Category: " + book.getCategory());
            System.out.println("--------------------------");
        }
    }
}
